# KEYSTONE Python Minimum Publishable Prototype

## Requirements

- Python 3.11 or newer
- `cryptography`, `matplotlib`, and `pytest`

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
```

## Run

From the archive root, use the `Makefile` targets described in the top-level `README.md` (`make r1-check`, `make r1-assets`, `make r1-run`, `make r1-testbed`, `make test-python`). Individual commands:

```bash
keystone demo
keystone bound --n 32 --threshold 22 --sample-size 8 --required-valid 8
pytest -q
```

## What the cryptographic demo implements

- dealer-based Shamir shares with Feldman commitments;
- dealer-based zero-polynomial share refresh for controlled experiments only;
- public per-member share commitments;
- deterministic beacon/context-derived hash-to-group canaries;
- Chaum–Pedersen/DLEQ proofs of equal discrete logs;
- threshold DH KEM wrapping a random AES-256 record key;
- AES-GCM record encryption and authenticated opening;
- invalid-partial and non-response evidence objects;
- separate audit and target-dispute behavior for selective withholding.

## What it deliberately does not implement

- production DKG/PVSS or proactive resharing;
- standardized curve/library-grade threshold cryptography;
- network transport, production key management, stake, or a TEE;
- proof that audit success guarantees future dispute cooperation;
- security against `t` compromised shares;
- cryptographic audit or production hardening.

## Result files

The evaluation's raw outputs are in `research-case/05-analysis/results/r1/`; generated tables and figures are in `paper/r1/`.

All reported performance numbers are environment-specific research baselines, not production capacity claims.
The Ed25519 response-signature helper signs the exact canonical transcript bytes;
its fixed-seed vector is test-only interoperability data, not secure key generation.
