# KEYSTONE: anonymized artifact (supplementary material for peer review)

This archive accompanies the manuscript *KEYSTONE: Auditable Dispute-Key Availability for Encrypted AI Rollups*. It contains everything needed to regenerate every table, figure and in-text number of the evaluation (Section 7).

## Contents

| Path | What it is |
|---|---|
| `prototype/src/keystone/` | Pure-Python reference implementation: threshold DH KEM, Shamir sharing with Feldman commitments, Chaum-Pedersen DLEQ proofs, canary derivation, audit and dispute paths, simulator |
| `prototype/scripts/run_r1_*.py` | Experiment drivers: prespecified simulation cells (`run_r1_pc03.py`), exact analyses (`run_r1_analytic.py`), microbenchmarks (`run_r1_microbench.py`), emulated deadline testbed (`run_r1_deadline_testbed.py`) |
| `prototype/scripts/build_r1_figures_tables.py` | Regenerates `paper/r1/tables/*.tex`, `paper/r1/tables/numbers.tex` (all in-text numbers) and `paper/r1/figures/*` from stored results |
| `prototype/tests/` | Unit and integration tests |
| `contracts/` | Solidity bulletin-board skeleton and Foundry tests (gas table) |
| `research-case/03-design/r1-reviewer-revision/` | Frozen experimental design (`r1-design-freeze.json`), its SHA-256 sums, deviation log, RFC 7919 group parameters |
| `research-case/05-analysis/results/r1/` | Raw outputs: per-block simulation CSVs, per-trace testbed CSVs with metadata, microbenchmark CSVs |
| `analysis/oc_analysis.py` | Exact operating-characteristic analysis (the operating-characteristic table and the margin and sequential-test numbers); `python3 analysis/oc_analysis.py` regenerates them |
| `paper/r1/tables`, `paper/r1/figures`, `paper/r1/r1-asset-manifest.json` | Generated assets and the manifest binding each asset to the SHA-256 of its inputs |

## Reproduce

Requirements: Python 3.13 with `uv`; Foundry (only for the gas table).

```
make setup        # create the locked environment
make r1-check     # verify the frozen design hashes and run the revision tests
make r1-assets    # regenerate tables, figures and numbers from the stored raw results
make r1-run       # re-run simulation cells, exact analyses and microbenchmarks
make r1-testbed   # re-run the 32-process emulated testbed (2,400 traces; slow)
make test-python  # full test suite
make test-contract
```

Every experiment script checks the SHA-256 of `r1-design-freeze.json` (`4c852969b615ba0dc6f935cff83aa3f0f35743168695948cf6898e8ba1932385`) before it runs, and every output records it.

## Anonymization note

This copy was prepared for review. Author names were removed from `LICENSE`. Project-management records and their tests, which play no part in reproduction, were omitted, including the authorization record named in `r1-design-freeze.json`; its line was therefore removed from `r1-design-freeze.SHA256SUMS`, and one entry about that record was removed from the deviation log. The design-freeze file itself and all results are byte-identical to the original, so its SHA-256 can be checked against the public repository identified on the title page.

## Scope

The prototype is a research reference implementation, not production software; it uses a dealer instead of distributed key generation and has not been externally audited. The 256-bit group is for fast tests only and is not a secure size.
