# KEYSTONE: anonymized artifact (supplementary material for peer review)

This archive accompanies the manuscript *KEYSTONE: Readiness Audits for Dispute-Key Availability in Encrypted Rollups*. It contains everything needed to regenerate every table, figure and in-text number of the evaluation (Section 7). Results come from two prototypes: R1 (pure-Python ffdhe groups) and R2 (ristretto255, TDH2, verification off the network loop), each run under its own frozen design.

## Contents

| Path | What it is |
|---|---|
| `prototype/src/keystone/` | Pure-Python reference implementation: threshold DH KEM, Shamir sharing with Feldman commitments, Chaum-Pedersen DLEQ proofs, canary derivation, audit and dispute paths, simulator |
| `prototype/scripts/run_r1_*.py` | Experiment drivers: prespecified simulation cells (`run_r1_pc03.py`), exact analyses (`run_r1_analytic.py`), microbenchmarks (`run_r1_microbench.py`), emulated deadline testbed (`run_r1_deadline_testbed.py`) |
| `prototype/scripts/build_r1_figures_tables.py` | Regenerates `paper/r1/tables/*.tex`, `paper/r1/tables/numbers.tex` (all in-text numbers) and `paper/r1/figures/*` from stored results |
| `prototype/tests/` | Unit and integration tests |
| `contracts/` | Solidity bulletin-board skeleton and Foundry tests (gas table) |
| `research-case/03-design/r1-reviewer-revision/` | Frozen experimental design (`r1-design-freeze.json`), its SHA-256 sums, deviation log, RFC 7919 group parameters |
| `research-case/05-analysis/results/r1/` | Raw outputs: per-block simulation CSVs, per-trace testbed CSVs with metadata, microbenchmark CSVs |
| `prototype/r2/` | R2 prototype (separate locked `uv` project): ristretto255 via `rbcl`, TDH2 with record labels, group-generic DLEQ with batch verification, canary audit with a cryptographic sampler, temporal readiness model (`keystone_r2/temporal.py`); tests; drivers `scripts/run_r2_microbench.py`, `run_r2_deadline_testbed.py`, `analyze_r2_deadline.py`, `run_r2_temporal.py` |
| `research-case/03-design/r2-design-amendment/` | R2 frozen design (`r2-design-freeze.json`) with SHA-256 sums, the deadline record fixed before the testbed, the deviation log (every change after freezing), the supply-chain review of `rbcl`, and `W1-THEOREMS.md` (statements and full proofs of the temporal results) |
| `research-case/05-analysis/results/r2/` | R2 raw outputs: microbenchmark runs, per-trace testbed CSVs with metadata and `deadline-summary.csv`, temporal exact grid, design intervals and simulation check |
| `research-case/03-design/r2b-replication/` | R2b pre-registered replication: freeze and deadline record (order-statistic deadline with calibrated B0), fixed before any R2b trace |
| `research-case/05-analysis/results/r2b/` | R2b calibration (null transport and zero-delay full path) and per-trace replication results with `r2b-summary.csv` and `r2b-paired.csv` |
| `paper/jcs/r2_assets.py` | Builds the R2 tables and in-text numbers of the article from the R2 results (`python3 paper/jcs/r2_assets.py`) |
| `analysis/oc_analysis.py` | Exact operating-characteristic analysis (the operating-characteristic table and the margin and sequential-test numbers); `python3 analysis/oc_analysis.py` regenerates them |
| `paper/r1/tables`, `paper/r1/figures`, `paper/r1/r1-asset-manifest.json` | Generated assets and the manifest binding each asset to the SHA-256 of its inputs |

## Reproduce

Requirements: Python 3.13 with `uv`; Foundry (only for the gas table).

```
make setup        # create the locked environment
make r1-check     # verify the frozen design hashes and run the revision tests
make r1-assets    # regenerate tables, figures and numbers from the stored raw results
make r1-run       # re-run simulation cells, exact analyses and microbenchmarks
make r1-testbed   # re-run the 32-process emulated testbed (2,400 traces; slow)
make test-python  # full test suite
make test-contract
```

R2 (from `prototype/r2`, after `uv sync --locked --extra dev`):

```
uv run --locked --extra dev python -m pytest -q                         # R2 correctness suite
uv run --locked --extra dev python scripts/run_r2_microbench.py         # microbenchmarks
uv run --locked --extra dev python scripts/run_r2_deadline_testbed.py SERIAL   # then BATCH (about 2.5 h each)
uv run --locked --extra dev python scripts/analyze_r2_deadline.py
uv run --locked --extra dev python scripts/run_r2_temporal.py all       # exact grid, design, simulation check
uv run --locked --extra dev python scripts/predict_r2_deadline.py       # post hoc order-statistic predictions
uv run --locked --extra dev python scripts/run_r2_transport_calibration.py
uv run --locked --extra dev python scripts/run_r2b_deadline_testbed.py SERIAL   # then BATCH (about 2.5 h each)
uv run --locked --extra dev python scripts/analyze_r2b_deadline.py
```

Every R2 script checks the SHA-256 of `r2-design-freeze.json` (`98e89893c06db3b68640038bb627b7e3e3892885c9a00e2849fba1a1763addb1`) and runs the correctness suite before it measures; every output records the hash.

Every R1 experiment script checks the SHA-256 of `r1-design-freeze.json` (`4c852969b615ba0dc6f935cff83aa3f0f35743168695948cf6898e8ba1932385`) before it runs, and every output records it.

## Anonymization note

This copy was prepared for review. Author names were removed from `LICENSE`. Project-management records and their tests, which play no part in reproduction, were omitted, including the authorization record named in `r1-design-freeze.json`; its line was therefore removed from `r1-design-freeze.SHA256SUMS`, and one entry about that record was removed from the deviation log. The design-freeze file itself and all results are byte-identical to the original, so its SHA-256 can be checked against the public repository identified on the title page. For R2, the authorization record was likewise omitted and its line removed from `r2-design-freeze.SHA256SUMS`; git commit identifiers in the environment and provenance records and in the deviation log were replaced by `[redacted]`. The R2 design-freeze file, the design draft it hashes and all result data files are unchanged; they cite the base commit of the repository the design was frozen against.

## Scope

The prototypes are research reference implementations, not production software; they use a dealer instead of distributed key generation and have not been externally audited. The 256-bit group is for fast tests only and is not a secure size.
